//
//  PCRegisterWebPManager.h
//  WKWebVIewHybridDemo
//
//  Created by 徐金城 on 2022/2/28.
//  Copyright © 2022 shuoyu liu. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface PCRegisterWebPManager : NSObject

+ (PCRegisterWebPManager *)shareManager;
- (void)registerWebPIntercept;       //注册
- (void)unregisterWebPIntercept;     //销毁

@end

NS_ASSUME_NONNULL_END

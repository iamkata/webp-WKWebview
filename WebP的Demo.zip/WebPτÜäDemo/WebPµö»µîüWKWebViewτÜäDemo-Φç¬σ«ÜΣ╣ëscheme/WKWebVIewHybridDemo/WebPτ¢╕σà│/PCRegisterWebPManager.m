//
//  PCRegisterWebPManager.m
//  WKWebVIewHybridDemo
//
//  Created by 徐金城 on 2022/2/28.
//  Copyright © 2022 shuoyu liu. All rights reserved.
//

#import "PCRegisterWebPManager.h"
#import "NSURLProtocol+WebPIntercept.h"
#import <WebKit/WebKit.h>

static NSString *const PCWebPInterceptProtocol_String = @"PCWebPInterceptProtocol";

@implementation PCRegisterWebPManager

+ (PCRegisterWebPManager *)shareManager{
    static PCRegisterWebPManager *manger;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        manger = [[PCRegisterWebPManager alloc] init];
    });
    return manger;
}

#pragma mark - WebView支持webP
// NSURLProtocol 一旦被注册将会使整个App的request请求都会被拦截,进入Web时注册,退出Web取消注册
/**
 注册 MagicURLProtocol
 */
- (void)registerWebPIntercept {
    [NSURLProtocol registerClass:NSClassFromString(PCWebPInterceptProtocol_String)];
    
//    [NSURLProtocol wk_registerScheme:@"http"];
//    [NSURLProtocol wk_registerScheme:@"https"];
    [NSURLProtocol wk_registerScheme:@"webphttp"]; //相当于http
    [NSURLProtocol wk_registerScheme:@"webphttps"]; //相当于https
}

/**
 销毁 MagicURLProtocol
 */
- (void)unregisterWebPIntercept {
    [NSURLProtocol unregisterClass:NSClassFromString(PCWebPInterceptProtocol_String)];
    
//    [NSURLProtocol wk_unregisterScheme:@"http"];
//    [NSURLProtocol wk_unregisterScheme:@"https"];
    [NSURLProtocol wk_unregisterScheme:@"webphttp"]; //相当于http
    [NSURLProtocol wk_unregisterScheme:@"webphttps"]; //相当于https
}

@end

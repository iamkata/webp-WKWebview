//
//  PCWebPInterceptProtocol.m
//  WKWebVIewHybridDemo
//
//  Created by shuoyu liu on 2017/1/16.
//  Copyright © 2017年 shuoyu liu. All rights reserved.
//

#import "PCWebPInterceptProtocol.h"
#import <UIKit/UIKit.h>
#ifdef SD_WEBP
#import "UIImage+WebP.h"
#endif

static NSString *const PCWebPInterceptKey = @"PCWebPInterceptKey";
static NSString *const InterceptRule = @".webp";
static NSString *const WebPPrefix = @"webp";

@interface PCWebPInterceptProtocol () <NSURLSessionDelegate>

@property (nonatomic, strong) NSURLSessionDataTask *task;  //拦截的任务
@property (nonatomic, strong) NSMutableData *recData;      //接收的数据

@end

@implementation PCWebPInterceptProtocol

- (void)dealloc {
    self.recData = nil;
}

- (NSMutableData *)recData {
    if (!_recData) {
        _recData = [NSMutableData new];
    }
    return _recData;
}

#pragma mark - NSURLProtocol方法

//1.询问是否拦截 YES:拦截  NO:不拦截
+ (BOOL)canInitWithRequest:(NSURLRequest *)request {
    NSLog(@"拦截的地址为%@",request.URL.absoluteString);
    NSString *urlStr = request.URL.absoluteString;
    if (SD_WEBP && [urlStr hasSuffix:InterceptRule]) {
        //如果打开SD_WEBP开关,并且.webp结尾,才拦截
        //看看是否已经处理过了，防止无限循环
        if ([NSURLProtocol propertyForKey:PCWebPInterceptKey inRequest:request]) {
            return NO;
        }
        return YES;
    }
    return NO;
}

//2.返回格式化后的request,必须实现,如果没特殊需求,直接返回
+ (NSURLRequest *)canonicalRequestForRequest:(NSURLRequest *)request {
    if ([request.URL.scheme hasPrefix:WebPPrefix]) {//如果是webp自定义图片协议
        NSMutableURLRequest *mRequest = [request mutableCopy];
        // 过滤自定义协议头
        NSMutableString *mUrl = [request.URL.absoluteString mutableCopy];
        NSRange range = [mUrl rangeOfString:WebPPrefix];
        [mUrl deleteCharactersInRange:range]; //删除webp前缀
        mRequest.URL = [NSURL URLWithString:[mUrl copy]];
        return [mRequest copy];
    }
    return request;
}

//3.自定义的NSURLProtocol拿到了request的操作权之后，在这个方法里就是执行拦截请求后的操作了
- (void)startLoading {
    NSMutableURLRequest *mutableReqeust = [self.request mutableCopy];
    //给我们处理过的请求设置一个标识符, 防止无限循环,
    [NSURLProtocol setProperty:@YES forKey:PCWebPInterceptKey inRequest:mutableReqeust];

    //TODO:这里最好加上缓存判断，加载本地离线文件

    if ([mutableReqeust.URL.absoluteString hasSuffix:InterceptRule]) {
        //复制request
        NSMutableURLRequest *newRequest = [self cloneRequest:self.request];
        [NSURLProtocol setProperty:@YES forKey:PCWebPInterceptKey inRequest:newRequest];
        //重新请求
        NSURLSessionConfiguration *config = [NSURLSessionConfiguration defaultSessionConfiguration];
        NSURLSession *session = [NSURLSession sessionWithConfiguration:config delegate:self delegateQueue:nil];
        self.task = [session dataTaskWithRequest:self.request];
        [self.task resume];
    }
}

//4. 请求结束时的方法
- (void)stopLoading {
    if (self.task) {
        [self.task cancel];
    }

    self.task = nil;
    self.recData = nil;
}

#pragma mark - NSURLSession代理方法

//收到服务端响应
- (void)URLSession:(NSURLSession *)session dataTask:(NSURLSessionDataTask *)dataTask didReceiveResponse:(NSURLResponse *)response completionHandler:(void (^)(NSURLSessionResponseDisposition))completionHandler {
    completionHandler(NSURLSessionResponseAllow);
}

//接收数据
- (void)URLSession:(NSURLSession *)session dataTask:(NSURLSessionDataTask *)dataTask didReceiveData:(NSData *)data {
    //拼接数据
    [self.recData appendData:data];
}

//加载完毕
//使用SDWebimage将webp图片转换格式
- (void)URLSession:(NSURLSession *)session task:(NSURLSessionTask *)task didCompleteWithError:(nullable NSError *)error {
    if (error) {
        // 通知client加载失败
        [self.client URLProtocol:self didFailWithError:error];
        return;
    }
    
    NSData *finalData = self.recData;
    NSHTTPURLResponse *response = (NSHTTPURLResponse *)task.response;
#ifdef SD_WEBP
    if ([self.request.URL.absoluteString hasSuffix:InterceptRule]) {
        //使用SDWebimage将webp图片转换格式
        UIImage *image = [UIImage sd_imageWithWebPData:finalData];
        finalData = UIImagePNGRepresentation(image);
        NSString *mimeType = @"image/png";
        if (!finalData) {
            finalData = UIImageJPEGRepresentation(image, 1);
            mimeType = @"image/jpeg";
        }
        NSMutableDictionary<NSString *, NSString *> *headers = [response.allHeaderFields mutableCopy];
        headers[@"Content-Type"] = mimeType;
        headers[@"Content-Length"] = @(finalData.length).stringValue;
        response = [[NSHTTPURLResponse alloc] initWithURL:response.URL statusCode:200 HTTPVersion:@"HTTP/1.1" headerFields:headers];
    }
#endif
    // NSURLCacheStorageNotAllowed URL的缓存策略,不缓存URL
    [self.client URLProtocol:self didReceiveResponse:response cacheStoragePolicy:NSURLCacheStorageNotAllowed];
    [self.client URLProtocol:self didLoadData:finalData];
    [self.client URLProtocolDidFinishLoading:self];
}

#pragma mark - other

//复制Request对象
- (NSMutableURLRequest *)cloneRequest:(NSURLRequest *)request {
    //创建newRequest
    NSMutableURLRequest *newRequest = [NSMutableURLRequest requestWithURL:request.URL cachePolicy:request.cachePolicy timeoutInterval:request.timeoutInterval];
    newRequest.allHTTPHeaderFields = request.allHTTPHeaderFields;
    [newRequest setValue:@"image/webp,image/*;q=0.8" forHTTPHeaderField:@"Accept"];
    if (request.HTTPMethod) {
        newRequest.HTTPMethod = request.HTTPMethod;
    }
    if (request.HTTPBodyStream) {
        newRequest.HTTPBodyStream = request.HTTPBodyStream;
    }
    if (request.HTTPBody) {
        newRequest.HTTPBody = request.HTTPBody;
    }
    newRequest.HTTPShouldUsePipelining = request.HTTPShouldUsePipelining;
    newRequest.mainDocumentURL = request.mainDocumentURL;
    newRequest.networkServiceType = request.networkServiceType;
    return newRequest;
}

@end


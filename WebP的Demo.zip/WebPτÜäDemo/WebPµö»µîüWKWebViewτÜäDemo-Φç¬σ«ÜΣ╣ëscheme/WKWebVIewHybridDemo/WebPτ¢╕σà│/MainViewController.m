//
//  MainViewController.m
//  WKWebVIewHybridDemo
//
//  Created by 徐金城 on 2022/3/1.
//  Copyright © 2022 shuoyu liu. All rights reserved.
//

#import "MainViewController.h"
#import "NSURLProtocol+WebPIntercept.h"
#import "PCRegisterWebPManager.h"
#import <WebKit/WebKit.h>

@interface MainViewController () <WKNavigationDelegate, WKUIDelegate>
@property (nonatomic) WKWebView *webView;

@end
@implementation MainViewController

- (void)viewDidLoad {
    [super viewDidLoad];

    [[PCRegisterWebPManager shareManager] registerWebPIntercept];

    [self.view addSubview:self.webView];
    self.webView.translatesAutoresizingMaskIntoConstraints = false;
    [NSLayoutConstraint activateConstraints:@[
        [self.webView.leadingAnchor constraintEqualToAnchor:self.view.leadingAnchor],
        [self.webView.trailingAnchor constraintEqualToAnchor:self.view.trailingAnchor],
        [self.webView.topAnchor constraintEqualToAnchor:self.view.safeAreaLayoutGuide.topAnchor],
        [self.webView.bottomAnchor constraintEqualToAnchor:self.view.safeAreaLayoutGuide.bottomAnchor],
    ]];

    // Do any additional setup after loading the view.
}

- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    [[PCRegisterWebPManager shareManager] unregisterWebPIntercept];
}

- (void)dealloc {
    [[PCRegisterWebPManager shareManager] unregisterWebPIntercept];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (WKWebView *)webView {
    if (!_webView) {
        WKWebViewConfiguration *configuration = [[WKWebViewConfiguration alloc] init];
        configuration.userContentController = [[WKUserContentController alloc] init];

        WKPreferences *preferences = [WKPreferences new];
        preferences.javaScriptCanOpenWindowsAutomatically = YES;
        preferences.minimumFontSize = 30.0;
        configuration.preferences = preferences;

        _webView = [[WKWebView alloc] initWithFrame:self.view.frame configuration:configuration];
        _webView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;

        if ([_webView respondsToSelector:@selector(setNavigationDelegate:)]) {
            [_webView setNavigationDelegate:self];
        }

        if ([_webView respondsToSelector:@selector(setDelegate:)]) {
            [_webView setUIDelegate:self];
        }

        //TODO:ios14以上支持webp
        
        //TODO:本地html文件测试
    //    NSString *path = [[NSBundle mainBundle] pathForResource:@"index" ofType:@"html"];
    //    NSURL *url = [NSURL fileURLWithPath:path];
    //    // NSURLRequestReloadIgnoringLocalCacheData 忽略系统缓存，重新请求
    //    NSURLRequest *request = [NSURLRequest requestWithURL:url cachePolicy:NSURLRequestReloadIgnoringLocalCacheData timeoutInterval:15.0];

        //TODO:直接加载webp图片测试
    //    NSURLRequest *request = [NSURLRequest requestWithURL:[NSURL URLWithString:@"https://pavo.elongstatic.com/i/mobile750_448/KhelRY5S80.webp"] cachePolicy:NSURLRequestReloadIgnoringLocalCacheData timeoutInterval:15.0];
    //    [_webView loadRequest:request];

        //TODO:网页中显示webp图片测试
//        NSURLRequest *request = [NSURLRequest requestWithURL:[NSURL URLWithString:@"http://isparta.github.io/compare-webp/index.html#12345"] cachePolicy:NSURLRequestReloadIgnoringLocalCacheData timeoutInterval:15.0];
            
        //TODO:ajax请求测试
        //ajax请求body会丢失,注释掉[[PCRegisterWebPManager shareManager] registerWebPIntercept];就正常
        NSURLRequest *request = [NSURLRequest requestWithURL:[NSURL URLWithString:@"https://fshluat.zj96596.com.cn:8001/mfs/page/favorites/shareDetail.html?PUBLISH_ID=8e1430d8-550a-49db-bff8-63ce4a995866"] cachePolicy:NSURLRequestReloadIgnoringLocalCacheData timeoutInterval:15.0];
//            
        [_webView loadRequest:request];
    }
    return _webView;
}

@end

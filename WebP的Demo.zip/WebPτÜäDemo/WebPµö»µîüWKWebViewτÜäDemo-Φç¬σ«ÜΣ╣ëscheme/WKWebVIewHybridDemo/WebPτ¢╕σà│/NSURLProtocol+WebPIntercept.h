//
//  NSURLProtocol+WebPIntercept.h
//  WKWebVIewHybridDemo
//
//  Created by shuoyu liu on 2017/1/15.
//  Copyright © 2017年 shuoyu liu. All rights reserved.
//
//  NSURLProtocol+MagicWebView用于提供WKWebView对NSURLProtocol的支持能力
//  UIWebView默认支持NSURLProtocol，如果需要WKWebView也支持NSURLProtocol，则需要本文件注册http(s) schme,把http https请求交给NSURLProtocol处理

#import <Foundation/Foundation.h>

@interface NSURLProtocol (WebPIntercept)

+ (void)wk_registerScheme:(NSString *)scheme;     //注册协议
+ (void)wk_unregisterScheme:(NSString *)scheme;   //注销协议

@end

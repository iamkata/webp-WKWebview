//
//  HybirdViewController.m
//  WKWebVIewHybridDemo
//
//  Created by shuoyu liu on 2017/1/17.
//  Copyright © 2017年 shuoyu liu. All rights reserved.
//

#import "HybirdViewController.h"
#import "MainViewController.h"
#import <SDWebImage/UIImageView+WebCache.h>

@interface HybirdViewController ()

@end

@implementation HybirdViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    UILabel *titleLab = [[UILabel alloc] init];
    titleLab.adjustsFontSizeToFitWidth = YES;
    titleLab.text = @"点击空白,使用WKWebView加载webp图片";
    self.navigationItem.titleView = titleLab;
    
#ifdef SD_WEBP
    UIImageView *imageV = [[UIImageView alloc] initWithFrame:CGRectMake(10, 100, 250, 150)];
    NSString *urlStr = @"https://pavo.elongstatic.com/i/mobile750_448/KhelRY5S80.webp";
    [imageV sd_setImageWithURL:[NSURL URLWithString:urlStr]];
    [self.view addSubview:imageV];
#else
    [self aaddTipLabel];
#endif
}


- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
#ifdef SD_WEBP
    MainViewController *vc = [[MainViewController alloc] init];
    [self.navigationController pushViewController:vc animated:YES];
#else
    [self aaddTipLabel];
#endif
}

- (void)addTipLabel {
    UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(10, 400, [UIScreen mainScreen].bounds.size.width - 20, 80)];
    label.numberOfLines = 0;
    label.adjustsFontSizeToFitWidth = YES;
    label.text = @"暂未打开'SD_WEBP'标记,请到BuildSetting里面,搜索Preprocessor Macros,添加'SD_WEBP=1标记'";
    [self.view addSubview:label];
}

@end

